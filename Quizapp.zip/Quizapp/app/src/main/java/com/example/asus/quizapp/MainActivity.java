package com.example.asus.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button submit = (Button) findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup RG1 = (RadioGroup) findViewById(R.id.RadioGroup1);
                RadioGroup RG2 = (RadioGroup) findViewById(R.id.RadioGroup2);
                RadioGroup RG3 = (RadioGroup) findViewById(R.id.RadioGroup3);

                EditText editText = (EditText) findViewById(R.id.name);
                String name = editText.getText().toString();
                EditText edit = (EditText) findViewById(R.id.osi);
                String osi = edit.getText().toString();
                String correctansor = "Seven";
                EditText edit1 = (EditText) findViewById(R.id.tcpp);
                String tcp_ip = edit1.getText().toString();
                String correcttcp = "Five";

                RadioButton tcp = (RadioButton) findViewById(R.id.tcp);
                RadioButton internetProtocol = (RadioButton) findViewById(R.id.internet_protocol);
                RadioButton Trransamation = (RadioButton) findViewById(R.id.transmatin_control_protocol);

                CheckBox chare = (CheckBox) findViewById(R.id.advantge_tru);
                CheckBox easy = (CheckBox) findViewById(R.id.advantage2_tru);
                CheckBox process = (CheckBox) findViewById(R.id.process);
                CheckBox require = (CheckBox) findViewById(R.id.requires);

                CheckBox bus = (CheckBox) findViewById(R.id.bus);
                CheckBox star = (CheckBox) findViewById(R.id.star);
                CheckBox line = (CheckBox) findViewById(R.id.line);
                CheckBox center = (CheckBox) findViewById(R.id.center);

                RadioButton selectradiobutoon = (RadioButton) findViewById(RG1.getCheckedRadioButtonId());
                RadioButton selectradiobutoon2 = (RadioButton) findViewById(RG2.getCheckedRadioButtonId());
                RadioButton selectradiobutoon3 = (RadioButton) findViewById(RG3.getCheckedRadioButtonId());

                if (osi.equals(correctansor)) {
                    score++;
                }
                if (tcp_ip.equals(correcttcp)) {
                    score++;
                }

                if (selectradiobutoon == tcp) {
                    score++;
                }

                if (selectradiobutoon2 == internetProtocol) {
                    score++;
                }

                if (selectradiobutoon3 == Trransamation) {
                    score++;
                }

                if (process.isChecked() || require.isChecked()) {

                } else if (chare.isChecked() && easy.isChecked()) {
                    score++;
                }

                if (line.isChecked() || center.isChecked()) {
                } else if (bus.isChecked() && star.isChecked()) {
                    score++;
                }
                Toast.makeText(MainActivity.this, "name is :" + name + "\nScore is: " + score, Toast.LENGTH_LONG).show();
                score = 0;

            }

        });


    }
}






